L1 = ["Amit", "Rahul", "Amit", "Neha", "Amit"]

name = input("Enter student name: ")

while name in L1:
    L1.remove(name)

print(L1)