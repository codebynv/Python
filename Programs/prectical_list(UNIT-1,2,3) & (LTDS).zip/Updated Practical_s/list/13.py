employees = [
["Amit",22,25000,"Python"],
["Rahul",25,35000,"Java"],
["Neha",24,30000,"Testing"]
]

name = input("Enter Employee Name: ")

found = False

for emp in employees:
    if emp[0] == name:
        print(emp)
        found = True

if found == False:
    print("Employee Not Found")