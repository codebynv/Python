L1 = ["Amit", "Rahul", "Amit", "Neha"]

name = input("Enter student name: ")

if name in L1:
    print("Count =", L1.count(name))
    print("First Position =", L1.index(name))
else:
    print("Student Not Found")