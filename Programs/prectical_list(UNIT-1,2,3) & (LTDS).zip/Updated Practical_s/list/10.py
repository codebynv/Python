L = [10,5,30,7,25,60,45,11,18,90]

print("Maximum =", max(L))
print("Minimum =", min(L))

"""
L = [10,5,30,7,25,60,45,11,18,90]

maximum = L[0]
minimum = L[0]

for i in L:
    if i > maximum:
        maximum = i

    if i < minimum:
        minimum = i

print("Maximum =", maximum)
print("Minimum =", minimum)
"""