t = (10,20,30,40,50)

for i in range(len(t)-1,-1,-1):
    print(t[i])