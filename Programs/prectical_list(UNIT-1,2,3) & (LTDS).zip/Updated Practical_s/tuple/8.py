cities = ("Ahmedabad","Surat","Rajkot","Vadodara","Bhavnagar")

for city in cities:
    print(city, len(city))

"""
cities = ("Ahmedabad","Surat","Rajkot","Vadodara","Bhavnagar")

for city in cities:

    count = 0

    for ch in city:
        count += 1

    print(city, count)
"""