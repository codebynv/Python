cities = ()

temp = []

for i in range(5):
    city = input("Enter city: ")
    temp.append(city)

cities = tuple(temp)

print(cities)