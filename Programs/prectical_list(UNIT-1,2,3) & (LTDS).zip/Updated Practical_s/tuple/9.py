name = input("Enter Name: ")

hobbies = (
input("Hobby1: "),
input("Hobby2: ")
)

friends = (
input("Friend1: "),
input("Friend2: ")
)

degree = input("Enter Degree: ")

t4 = (name,hobbies,friends,degree)

print(t4)