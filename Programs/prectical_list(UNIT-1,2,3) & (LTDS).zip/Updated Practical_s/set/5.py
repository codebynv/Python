# Checking existence in set (O(1) average lookup time)
frameworks = {"Django", "Flask", "FastAPI"}

print("Is 'Flask' present?", "Flask" in frameworks)
print("Is 'Spring' missing?", "Spring" not in frameworks)