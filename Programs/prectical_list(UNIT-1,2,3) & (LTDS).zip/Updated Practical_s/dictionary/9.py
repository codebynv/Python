# Merging two dictionaries using update() and union operator
dict1 = {"a": 1, "b": 2}
dict2 = {"b": 20, "c": 30}

# Method 1: update()
merged1 = dict1.copy()
merged1.update(dict2)
print("Merged using update():", merged1)

# Method 2: '|' Operator
merged2 = dict1 | dict2
print("Merged using '|':", merged2)