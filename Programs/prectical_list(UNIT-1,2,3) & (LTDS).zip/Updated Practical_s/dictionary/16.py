# Initializing with default values and resetting dictionary
keys = ["a", "b", "c"]
default_dict = dict.fromkeys(keys, 0)
print("Default Dict:", default_dict)

default_dict.clear()
print("Cleared Dict:", default_dict)