# Checking if keys or values exist in a dictionary
user = {"username": "admin", "role": "editor", "active": True}

print("Is 'role' a key?", "role" in user)
print("Is 'email' a key?", "email" in user)
print("Is 'editor' a value?", "editor" in user.values())