# 1.15 Multiplication Table
n = int(input("Enter number N: "))

for i in range(1, 11):
    print(f"{n} x {i} = {n * i}")