# 1.2 Formatted Introduction
name = input("Enter your name: ")
age = input("Enter your age: ")
city = input("Enter your favourite city: ")

print(f"Hello! My name is {name}. I am {age} years old and I love {city}.")