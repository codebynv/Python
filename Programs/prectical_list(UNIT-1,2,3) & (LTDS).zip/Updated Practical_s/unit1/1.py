# Hello World & Intro
print("Name: Joe Doe")
print("Roll Number: 20261012")
print("Programme: M.Sc. IT")
print("Semester: 1st Semester")