# 3.8 String Methods Practice

text = " python programming is versatile and easy to learn "
print(f"Original Text: '{text}'")

print(f"(a) upper(): {text.upper()}")
print(f"(b) lower(): {text.lower()}")
print(f"(c) title(): {text.title()}")
print(f"(d) strip(): '{text.strip()}'")
print(f"(e) split(): {text.strip().split()}")
print(f"(f) replace spaces: {text.strip().replace(' ', '_')}")
print(f"(g) find('a'): {text.find('a')}")
